#include <iostream>

int MCD(int, int);
int main() {

    int var1, var2;
    int result;

    printf("Ingrese el valor de M: ");
    scanf("%d", &var1);

    printf("Ingrese el valor de N: ");
    scanf("%d", &var2);


    if (var2 > var1 ){
        result = MCD(var2,var1);
    } else {
        result = MCD(var1,var2);
    }
    printf("El MCD de %d y %d es: %d", var1, var2, result);


    return 0;
}
    int MCD(int m, int n) {
    if (n == 0) return m;
    return MCD(n, m % n);
}