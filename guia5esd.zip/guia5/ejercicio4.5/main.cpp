#include <iostream>
#define N 3


   int xx[] = {1,0,-1,0};
   int yy[]= {0,1,0,-1};

    int matriz[N][N];
    int fin =0;

    void method(int x, int y){
        if(x<0 || y < 0) return;
        if(x >= N || y >= N) return;
       if(matriz[x][y] == -1) return;
       if(matriz[x][y] == 1) return;

       if(x == 0 && y==0){
           fin  = 1;
           printf("Lllegaste al final del laberinto \n");
           printf("EL recorrido fue: (%d,%d) \n", 0,0);
           return;

       }
       matriz[x][y]=1;
       for(int i =0; i<4; i++){
           method(x+xx[i],y+yy[i]);
           if( fin){
               printf("Recorrio: (%d,%d)\n",x,y);
               return;
           }
       }
    }
int main() {
        printf("EL laberinto es: %d,%d\n",N,N);

        printf("Ingrese el numero de obstaculos que desee:\n");
        int c;
        scanf("%d",&c);

        int x,y;
        for(int i=0; i<N, i++){
            for(int j=0; j<N; j++){
                matriz[i][j]=0;

            }
        }
        for(int i=0; i<c; i++){
            printf("Ingrese obstaculo %d[0,%d]: \n", i, N-1);
            scanf("%d",&x);
            scanf("%d",&y);
            matriz[x][y]= -1;
        }
        for(int i =0; i<N; i++ ){
            for( int j =0; j<N; j++){
                if(matriz[j][i] == -1);
                printf(("*");

            } else{
                printf("%d",matriz[j][i]);
            }

        }
        printf("\n");
        method(N-1,N-1);
    return 0;
}