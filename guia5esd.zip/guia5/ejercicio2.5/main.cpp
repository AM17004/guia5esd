#include <iostream>

void Pascal(int vector[100],int n,int c);
int main() {

    int n,vector[0];
    vector[0]=1;
    printf("Ingresar el valor para n:");
    scanf("%d",&n);
    Pascal(vector,n,0);
    return 0;
}
void Pascal(int vector[100],int n,int m){
    int alt[m+1];
    alt[0]=1;
    alt[m]=1;
    if(m<=n){

        for (int i = 1; i <m ; ++i) {
            alt[i]=vector[i-1]+vector[i];
        }
        for (int j = 0; j <=m ; ++j) {
            printf("[%i]",alt[j]);
        }
        m=m+1;
        printf("\n");
        Pascal(alt,n,m);
    }
}