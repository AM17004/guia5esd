#include <iostream>


    char num[] = {'0', '1', '2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
    void base(int n){
        if(n<16){
            printf("%c", num[n]);
            return;
        }
        base(n/16);
        int numb = (n%16);
        printf("%c", num[numb]);

    }
    void bsB(int n, int b) {
        if (n < b) {
            printf("%c", num[n]);
            return;
        }
        bsB(n / b, b);
        int numb = n % b;
        printf("%c", num[numb]);
    }
        int main() {
          printf("Ingrese el numero: \n");
          int n;
          scanf("%d",&n);
          printf("Ingrese la base menor que 10\n");
          int b;
          scanf("%d,&b");

          printf("El numero en base B es: ", bsB);

          printf("\n");


    return 0;
}